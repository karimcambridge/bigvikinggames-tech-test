package com.bigvikinggames.interview.serialization.protocol;

import com.bigvikinggames.interview.serialization.model.Message;

/**
 * Created by cbanner on 2017-05-11.
 */
public class SerializerImpl implements Serializer {

	@Override
	public byte[] serialize(Message message) {
		return new byte[0];
	}

}
